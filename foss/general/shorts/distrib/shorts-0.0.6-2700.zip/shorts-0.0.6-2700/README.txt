shorts - a Python program

shorts reads all the directories in shortspath and builds group_login.bat

Howto

The shorts procedure is to:

1. create a novell security group

2. update the wts_profile.central.mcm script to include the new group

3. create a dir <shortspath>\<group> named to EXACTLY match the new group
and to contain the payload of files to be delivered to group members

4. Every time wts_profile changes as a result of an admin performing the
above three steps, this program needs to be run so that the group_login.bat
always exactly complements the wts_profile login script.


Background
==========
Every login script for each local Novell server should set an environment
variable called "shortspath" to nominate the the local shortspath - for
example ...

  SET shortspath="\mcm_northern_srv\sys\PUBLIC\shorts"

In wts_profile.central.mcm this will be over-ridden with ...

  SET shortspath="\mcm_main_srv\sys\PUBLIC\shorts"

... so that the correct shortspath will be included no matter what. This
also ensures the local group_login.bat files is executed before the
central.mcm login is run to include additional items.

To prevent the wts_profile.central.mcm script from running, finish the local
login script with the Novell EXIT command.

1. wts_profile.central.mcm creates the shortspath environment variable

2. wts_profile.central.mcm creates a non-blank environment var for every
group the user is in

3. wts_profile.central.mcm final command is <shortspath>\group_login.bat

4. group_login.bat tests every group name it knows about and if it exists as a
non-blank environment var treats it as a hit and delivers the payload

5. group_login.bat clears out all the group environment vars

6. wts_profile EXITs


How does shorts.exe work?
=========================
This program re-writes <shortspath>\group_login.bat when it is manually
executed after someone has implemented a change in shorts. This might be
a new group or removal of an old group.

1. It reads the %shortspath% environment variable to discover where the
group_login.bat file should be. Failing that, it defaults to ...

    \Mcm_main_srv\sys\PUBLIC\shorts

2. It scans the directory names in %shortspath% to discover which groups
exist. This makes it important for admins to keep those directories in
step with groups listed in wts_profile.central.mcm

3. It uses those directory names to build group_login.bat from scratch
overwiting the previous version.

4. Everyone who logs in gets group_login.bat run for them by the Novell
login script mechanism which calls wts_profile.central.mcm

5. group_login.bat delivers the files and shortcuts allocated as payload
for all members of the groups concerned.



Source:  Userid is 'public' with no password.
http://svn.pczen.com.au/repos/pysrc/gpl3/general/shorts/distrib/

Mike Dewhirst
0411 704 143
miked@dewhirst.com.au
