longdesc = """shorts reads all the directories in shortspath and builds group_login.bat"""

longerdesc = """The shorts procedure is to:

1. create a novell security group

2. update the wts_profile.central.mcm script to include the new group

3. create a dir <shortspath>\<group> named to EXACTLY match the new group
and to contain the payload of files to be delivered to group members

4. Every time wts_profile changes as a result of an admin performing the
above three steps, this program needs to be run so that the group_login.bat
always exactly complements the wts_profile login script.


Background
==========
Every login script for each local Novell server should set an environment
variable called "shortspath" to nominate the the local shortspath - for
example ...

  SET shortspath="\\mcm_northern_srv\sys\PUBLIC\shorts"

In wts_profile.central.mcm this will be over-ridden with ...

  SET shortspath="\\mcm_main_srv\sys\PUBLIC\shorts"

... so that the correct shortspath will be included no matter what. This
also ensures the local group_login.bat files is executed before the
central.mcm login is run to include additional items.

To prevent the wts_profile.central.mcm script from running, finish the local
login script with the Novell EXIT command.

1. wts_profile.central.mcm creates the shortspath environment variable

2. wts_profile.central.mcm creates a non-blank environment var for every
group the user is in

3. wts_profile.central.mcm final command is <shortspath>\group_login.bat

4. group_login.bat tests every group name it knows about and if it exists as a
non-blank environment var treats it as a hit and delivers the payload

5. group_login.bat clears out all the group environment vars

6. wts_profile EXITs


How does shorts.exe work?
=========================
This program re-writes <shortspath>\group_login.bat when it is manually
executed after someone has implemented a change in shorts. This might be
a new group or removal of an old group.

1. It reads the %shortspath% environment variable to discover where the
group_login.bat file should be. Failing that, it defaults to ...

    \\Mcm_main_srv\sys\PUBLIC\shorts

2. It scans the directory names in %shortspath% to discover which groups
exist. This makes it important for admins to keep those directories in
step with groups listed in wts_profile.central.mcm

3. It uses those directory names to build group_login.bat from scratch
overwiting the previous version.

4. Everyone who logs in gets group_login.bat run for them by the Novell
login script mechanism which calls wts_profile.central.mcm

5. group_login.bat delivers the files and shortcuts allocated as payload
for all members of the groups concerned.

"""

source = """Source:  Userid is 'public' with no password.
http://svn.pczen.com.au/repos/pysrc/gpl3/general/shorts/distrib/

Mike Dewhirst
0411 704 143
miked@dewhirst.com.au
"""

relnote = """shorts - see below for description
=======

Version    Build  Who   When/What
================================
ver 0.0.6  2700   md    7-apr-2011  - Re-worked the last section of the output to
                        get everything in ~desktop and added more explanatory text.

ver 0.0.5  2697   md    5-apr-2011  - Re-worded the last section of the output
                        to provide a little guidance to users.

ver 0.0.4  2696   md    5-apr-2011  - adjusted to avoid directories beginning
                        with a tilde. Need a mechanism to skip other dirs.

ver 0.0.3  2695   md    5-apr-2011  - adjusted to avoid directories beginning
                        with a dot. It was picking up .svn directories.

ver 0.0.2  2693   md    30-mar-2011 - refactored to simplify it

ver 0.0.1  2688   md    28-mar-2011 - first written


Description
===========
%s

%s

%s

License
=======
Copyright (C) 2011 Mike Dewhirst

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

""" % (longdesc, longerdesc, source)

__doc__ = relnote

import os
try:
    shortspath = os.environ['shortspath']
    if not os.path.isdir(shortspath):
        raise KeyError
except KeyError:
    # pleeeease guarantee that this dir exists
    shortspath = r'\\Mcm_main_srv\sys\PUBLIC\shorts'
    if os.environ['computername'] == 'DEV-WX':
        shortspath = r'\\pq8nw\sys\PUBLIC\shorts'
        print(shortspath)


header = """@echo off
rem - DO NOT EDIT EXCEPT FOR TESTING - this file is recreated
rem - programmatically by running shorts.exe. This should be
rem - done after any changes to WTS_PROFILE and the resulting
rem - changes to sub-directories in %s
rem - To get permanent changes adjust the program source prior
rem - to running it again. See miked - 0411 704 143.


rem - Commands in this section run every time this file is executed

if not exist i:\shorts (mkdir i:\shorts > NUL)

================================================================
rem - Commands in this middle section ONLY work when this batch file runs
rem - automatically at login. Nothing in this section works at other times.
""" % shortspath

desktop = r'%USERPROFILE%\Desktop'

footer = """================================================================

rem - This last section copies everything in ~desktop to every user
rem - desktop provided the date on the file in ~desktop is newer than
rem - the same file on users actual desktop.

rem - Anything in this section will work every time this batch file runs.

xcopy "{1}\~desktop\*.*" "{0}" /D /S /C /I /H /R /Y /Z /Q /EXCLUDE:{1}\exclude.svn > NUL

""".format(desktop, shortspath)

groups = list()
for item in os.listdir(shortspath):
    dirpath = os.path.join(shortspath, item)
    if os.path.isdir(dirpath):
        if not item[0] == '.':
            if not item[0] == '~':
                groups.append(item.lower())


admin = 'administrators'
try:
    # bring administrators to the top of the list
    x = groups.index(admin)
    #print('%s' % x)
    groups.insert(0, groups[x])
    del groups[x + 1]
except ValueError:
    pass

middle = '\nset admin=\n\n'
for item in groups:
    if not item == admin:
        middle += 'if not xx%admin% == xx ( set admin=\\' + item + ' )\n'
    middle += 'if not xx%' + item + '% == xx (' + '\n'
    middle += '  xcopy "' + shortspath + '\\' + item + '\\*.*" i:\\shorts%admin% '
    middle += '/D /S /C /I /H /R /Y /Z /Q /EXCLUDE:' + shortspath
    middle += '\\exclude.svn > NUL\n'
    # comment the next line to leave environment vars in place
    middle += '  set ' + item + '=\n'
    if item == admin:
        middle += '  set admin=yes\n'
    middle += ')\n\n'

batfile = os.path.join(shortspath, 'group_login.bat')

with open(batfile, 'w') as fsock:
    fsock.write(header.encode('utf-8'))
    fsock.write(middle.encode('utf-8'))
    fsock.write(footer.encode('utf-8'))


